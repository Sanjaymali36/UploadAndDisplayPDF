from django.contrib import admin
from .models import Upload_Pdf
# Register your models here.
admin.site.register(Upload_Pdf)